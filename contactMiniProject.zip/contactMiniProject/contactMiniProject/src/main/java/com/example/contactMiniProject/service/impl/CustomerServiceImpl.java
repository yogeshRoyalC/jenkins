package com.example.contactMiniProject.service.impl;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Service;

import com.example.contactMiniProject.dto.CustomerDto;
import com.example.contactMiniProject.entity.Customer;
import com.example.contactMiniProject.repository.CustomerRepository;
import com.example.contactMiniProject.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService {

	private CustomerRepository customerRepository;
	private ModelMapper modelMapper;

	

	public CustomerServiceImpl(CustomerRepository customerRepository, ModelMapper modelMapper) {
		this.customerRepository = customerRepository;
		this.modelMapper = modelMapper;
	}

	@Override
	public CustomerDto createCustomer(CustomerDto customerDto) {
		// MAP Were are supplying Dto obj and converting into customer OBJ
		Customer map = modelMapper.map(customerDto, Customer.class);
		// saving to database (entity)
		Customer save = customerRepository.save(map);
		// custmer Dto obj converting into cust Entity type
		// Match Line 25 CustomerDto to Line no 32 CustomerDto return type should be
		// match
		CustomerDto map2 = modelMapper.map(save, CustomerDto.class);
		return map2;
	}

	@Override
	public List<CustomerDto> getAllCustomers() {
		return null;
	}

	@Override
	public CustomerDto getCustomerById(Long customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CustomerDto updateCustomer(Long customerId, CustomerDto customerDto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteCustomer(Long CustomerId) {
		// TODO Auto-generated method stub

	}

}