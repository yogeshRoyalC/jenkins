package com.example.contactMiniProject.service;

import java.util.List;

import com.example.contactMiniProject.dto.CustomerDto;


public interface CustomerService {

    List<CustomerDto> getAllCustomers();

    CustomerDto getCustomerById(Long customerId);

    public CustomerDto createCustomer(CustomerDto customerDto);

    CustomerDto updateCustomer(Long customerId, CustomerDto customerDto);

    void deleteCustomer(Long CustomerId);

}
