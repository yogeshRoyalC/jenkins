package com.example.contactMiniProject.controller;

import com.example.contactMiniProject.dto.CustomerDto;
import com.example.contactMiniProject.entity.Customer;
import com.example.contactMiniProject.service.CustomerService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
public class CustomerController {
	private final CustomerService customerService;

	public CustomerController(CustomerService customerService) {
		this.customerService = customerService;
	}

	@RequestMapping("/")
	public String welcome() {
		return "welcome";
	}

	@RequestMapping("/createCustomer")
	public String createCustomer() {
		return "createCustomer";
	}

	@RequestMapping("/saveCustomer")
	//saveCustomer
	public String saveCustomer(CustomerDto customerDto, Model model) {
		CustomerDto customer = customerService.createCustomer(customerDto);
		model.addAttribute("customer", customer);
		return "welcome";

	}
	
	@RequestMapping("/allCustomers")
	public String getAllCustomer(Model model) {
		List<CustomerDto> allCustomers = customerService.getAllCustomers();
		model.addAttribute("allCustomers", allCustomers);
		return "allCustomers";
	}
}
