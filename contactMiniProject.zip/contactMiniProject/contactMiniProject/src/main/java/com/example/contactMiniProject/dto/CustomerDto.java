package com.example.contactMiniProject.dto;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class CustomerDto {

    private Long customerId;
    //@Size(min = 3, max = 56, message = "please enter name between 3-16 characters")
    //@NotEmpty(message = "please enter name")
    private String name;
    //@NotEmpty(message = "please enter your salary")
    private double salary;
    //@NotEmpty(message = "please enter your address")
   //@Size(min = 5, max = 50, message = "please enter your address between 5-50 characters")
    private String address;
}
