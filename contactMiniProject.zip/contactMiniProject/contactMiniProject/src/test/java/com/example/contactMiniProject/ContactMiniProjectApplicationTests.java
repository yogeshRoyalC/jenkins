package com.example.contactMiniProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactMiniProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
